import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import * as topojson from 'topojson-client';
import world from 'world-atlas/countries-50m.json';
import minard from '@stdlib/datasets-minard-napoleons-march';

export default function MinardMap() {
    const svgRef = useRef();

    const drawMap = () => {
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a blue rectangle to represent the sea
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', '#87CEEB'); // Sky blue color

        const projection = d3.geoMercator()
            .center([31, 54.3]) // Center on Europe
            .scale(4200) // Adjust scale for better zoom on Europe
            .translate([window.innerWidth / 2, window.innerHeight / 2]);

        const path = d3.geoPath().projection(projection);

        svg.append('path')
            .datum(topojson.feature(world, world.objects.countries))
            .attr('d', path)
            .attr('fill', '#f0e4d7') // Old paper color
            .attr('stroke', '#8b4513') // Dark brown
            .attr('stroke-opacity', 0.4);

        // Get river data from minard dataset
        const riverData = minard({ data: 'rivers' });

        // Draw rivers
        svg.selectAll('.river')
            .data(riverData.features)
            .enter()
            .append('path')
            .attr('class', 'river')
            .attr('d', path)
            .attr('fill', 'none')
            .attr('stroke', '#87CEEB') // Sky blue color
            .attr('stroke-width', 2)
            .attr('stroke-opacity', 0.5);

        // Get army data from minard dataset
        const armyData = minard({ data: 'army' });

        // Define a scale for line width based on army size
        const widthScale = d3.scaleLinear()
            .domain([0, d3.max(armyData, d => d.size)])  // Using the maximum size in the dataset
            .range([1, 60]); // Line width will range from 1 to 60 pixels

        // Draw all lines first (both 'R' and non-'R')
        const lines = [];

        for (let i = 0; i < armyData.length - 1; i++) {
            const currentPoint = armyData[i];
            const nextPoint = armyData[i + 1];

            if (currentPoint.group === nextPoint.group) {
                const line = svg.append('line')
                    .attr('x1', projection([currentPoint.lon, currentPoint.lat])[0])
                    .attr('y1', projection([currentPoint.lon, currentPoint.lat])[1])
                    .attr('x2', projection([nextPoint.lon, nextPoint.lat])[0])
                    .attr('y2', projection([nextPoint.lon, nextPoint.lat])[1])
                    .attr('stroke-width', widthScale(currentPoint.size))
                    .attr('stroke-linecap', 'round')
                    .attr('opacity', 1);

                if (currentPoint.direction === 'R') {
                    if (currentPoint.division === 1) {
                        line.attr('stroke', '#FF6347'); // Light coral color
                    } else if (currentPoint.division === 2) {
                        line.attr('stroke', '#FF3E00'); // Slightly darker orange red color
                    } else {
                        line.attr('stroke', '#8B0000'); // Dark red color
                    }
                } else {
                    if (currentPoint.division === 1) {
                        line.attr('stroke', '#4682B4'); // Steel blue color
                    } else if (currentPoint.division === 2) {
                        line.attr('stroke', '#4169E1'); // Royal blue color
                    } else {
                        line.attr('stroke', '#00008B'); // Dark blue color
                    }
                }

                // Store lines for reordering later
                lines.push({ line, direction: currentPoint.direction });
            }
        }

        // Raise lines attack lines so that retreat lines stay under them
        lines.forEach(({ line, direction }) => {
            if (direction !== 'R') {
                line.raise();
            }
        });

        // Draw circles and labels for cities
        const cities = minard({ data: 'cities' });

        cities.forEach(city => {
            svg.append('text')
                .attr('x', projection([city.lon, city.lat])[0])
                .attr('y', projection([city.lon, city.lat])[1])
                .text(city.city)
                .attr('font-size', '14px')
                .attr('fill', '#000000')
                .attr('font-family', 'Georgia'); // old-style font
        });

        const legendData = [
            { color: '#4682B4', text: 'Attack Division 1', column: 0 },
            { color: '#4169E1', text: 'Attack Division 2', column: 0 },
            { color: '#00008B', text: 'Attack Division 3', column: 0 },
            { color: '#FF6347', text: 'Retreat Division 1', column: 1 },
            { color: '#FF3E00', text: 'Retreat Division 2', column: 1 },
            { color: '#8B0000', text: 'Retreat Division 3', column: 1 },
            { color: '#87CEEB', text: 'Rivers', column: 2 },
            { color: 'orange', text: 'Temperature', column: 2 },
        ];

        // Draw legend box
        const legend = svg.append('g')
            .attr('transform', `translate(${window.innerWidth - 420}, 40)`);

        legend.append('rect')
            .attr('width', 400) 
            .attr('height', 100)
            .attr('fill', 'white')
            .attr('stroke', 'black')
            .attr('stroke-width', 1)
            .attr('opacity', 0.4);

        legend.selectAll('.legend-item')
            .data(legendData)
            .enter()
            .append('g')
            .attr('class', 'legend-item')
            .attr('transform', (d, i) => `translate(${d.column * 140 + 10}, ${20 + (i % 3) * 25})`)
            .each(function (d) {
                d3.select(this).append('rect')
                    .attr('width', 18)
                    .attr('height', 18)
                    .attr('fill', d.color);

                d3.select(this).append('text')
                    .attr('x', 24)
                    .attr('y', 9)
                    .attr('dy', '0.35em')
                    .attr('font-size', '12px')
                    .text(d.text);
            });

        // Get temperature data from minard dataset
        const tempData = minard({ data: 'temperature' });

        // Set up temperature chart dimensions
        const tempMargin = { top: window.innerHeight - 280, right: 50, bottom: 50, left: 50 };
        const tempHeight = 150;

        // Align temperature chart with the x-axis of the main map by using the projection's x-coordinates
        const yScale = d3.scaleLinear()
            .domain([d3.min(tempData, d => d.temp), d3.max(tempData, d => d.temp)])
            .range([tempMargin.top + tempHeight, tempMargin.top]);

        // Draw temperature line
        const lineGenerator = d3.line()
            .x(d => projection([d.lon, 55])[0]) // Use map projection for the x-coordinate
            .y(d => yScale(d.temp));

        svg.append('path')
            .datum(tempData)
            .attr('fill', 'none')
            .attr('stroke', 'orange')
            .attr('stroke-width', 2)
            .attr('stroke-dasharray', '5,5')
            .attr('d', lineGenerator);

        // Draw circles at each data point
        svg.selectAll('.temp-circle')
            .data(tempData)
            .enter()
            .append('circle')
            .attr('class', 'temp-circle')
            .attr('cx', d => projection([d.lon, 55])[0])
            .attr('cy', d => yScale(d.temp))
            .attr('r', 3)
            .attr('fill', 'orange');

        // Add text labels for each data point
        svg.selectAll('.temp-label')
            .data(tempData)
            .enter()
            .append('text')
            .attr('class', 'temp-label')
            .attr('x', d => projection([d.lon, 55])[0] - 10) // Align text with the point
            .attr('y', d => yScale(d.temp) - 15) 
            .attr('dy', '.35em')
            .attr('font-size', '12px')
            .attr('fill', 'black')
            .text(d => d.temp);

        // Draw axes for the temperature chart
        const xAxis = d3.axisBottom(d3.scaleLinear()
            .domain(d3.extent(tempData, d => d.lon))
            .range([projection([d3.extent(tempData, d => d.lon)[0], 55])[0], projection([d3.extent(tempData, d => d.lon)[1], 55])[0]]))
            .ticks(5)
            .tickFormat(d => `Lon ${d}`);

        // Add horizontal grid lines for temperature chart
        svg.selectAll('.grid-line')
            .data(yScale.ticks(5))
            .enter()
            .append('line')
            .attr('class', 'grid-line')
            .attr('x1', projection([d3.extent(tempData, d => d.lon)[0], 55])[0])
            .attr('x2', projection([d3.extent(tempData, d => d.lon)[1], 55])[0])
            .attr('y1', d => yScale(d))
            .attr('y2', d => yScale(d))
            .attr('stroke', 'lightgray')
            .attr('stroke-dasharray', '2,2');

        const yAxis = d3.axisLeft(yScale).ticks(5).tickFormat(d => `${d}°C`);

        svg.append('g')
            .attr('transform', `translate(0, ${tempMargin.top + tempHeight})`)
            .call(xAxis)
            .selectAll('text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        // Corrected x-coordinate for y-axis
        svg.append('g')
            .attr('transform', `translate(${projection([d3.extent(tempData, d => d.lon)[0], 55])[0]}, 0)`)
            .call(yAxis)
            .selectAll('text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        // Draw lines connecting temperature points to the map
        tempData.forEach(temp => {
            const mapX = projection([temp.lon, 55])[0];
            const mapY = projection([temp.lat, 55])[1];
            const chartX = mapX; 
            const chartY = yScale(temp.temp);

            svg.append('line')
                .attr('x1', mapX)
                .attr('y1', mapY + 100)
                .attr('x2', chartX)
                .attr('y2', chartY)
                .attr('stroke', 'gray')
                .attr('stroke-dasharray', '4 4')
                .attr('opacity', 0.5);
        });

        svg.append('text')
            .attr('x', window.innerWidth / 2)
            .attr('y', 100)
            .attr('text-anchor', 'middle')
            .attr('font-size', '30px')
            .attr('fill', 'black') 
            .attr('font-family', 'Georgia')
            .attr('font-weight', 'bold')
            .attr('opacity', 0.8)
            .text("Napoleon's Russian Campaign");
    };

    useEffect(() => {
        drawMap();
        window.addEventListener('resize', drawMap);
        return () => window.removeEventListener('resize', drawMap);
    }, []);

    return <svg ref={svgRef}></svg>;
}
