import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

// Import flag images (assuming you have a flag image for each country in a directory)
import flags from '../data/country-flags'; // This should be an object mapping country names to image paths

export default function GDPLifeExpCountry() {
    const svgRef = useRef();

    const margin = { top: 50, right: 50, bottom: 50, left: 150 };
    const width = window.innerWidth - margin.left - margin.right;
    const height = window.innerHeight - margin.top - margin.bottom;

    const drawChart = () => {
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');

        // Read in the data where the year is 2002
        const data = inputData.filter(d => d.year === 2002);

        // Define scales
        const x = d3.scaleLinear()
            .domain(d3.extent(data, d => d.gdpPercap))
            .range([margin.left, width - margin.right]);

        const y = d3.scaleLinear()
            .domain(d3.extent(data, d => d.lifeExp))
            .range([height - margin.bottom, margin.top]);

        const r = d3.scaleLinear()
            .domain(d3.extent(data, d => d.pop))
            .range([10, 100]);

        // Draw images instead of circles
        svg.selectAll('image')
            .data(data)
            .enter()
            .append('image')
            .attr('xlink:href', d => {
            const countryData = flags.find(flag => flag.name === d.country);
            return countryData ? countryData.image : ''; // Use the flag image for the country
            })
            .attr('x', d => x(d.gdpPercap) - r(d.pop) / 2) // Center the image
            .attr('y', d => y(d.lifeExp) - r(d.pop) / 2) // Center the image
            .attr('width', d => r(d.pop))
            .attr('height', d => r(d.pop))
            .attr('opacity', 1);

        // Add labels
        /*
        svg.selectAll('.country-label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'country-label')
            .attr('x', d => x(d.gdpPercap))
            .attr('y', d => y(d.lifeExp))
            .text(d => d.country)
            .attr('font-size', '11px')
            .attr('text-anchor', 'middle')
            .attr('alignment-baseline', 'middle')
            .attr('fill', 'black');
        */

        // Add axes
        const xAxis = d3.axisBottom(x).ticks(10).tickFormat(d3.format(".2s"));
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(xAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px')
            .attr('stroke', 'black');

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        const yAxis = d3.axisLeft(y).ticks(10).tickFormat(d3.format(".2s"));
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(yAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px')
            .attr('stroke', 'black');

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('GDP per Capita')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Life Expectancy')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Add legend
        const legendData = [
            { continent: 'Asia', color: '#d62728' },
            { continent: 'Europe', color: '#1f77b4' },
            { continent: 'Africa', color: '#ff7f0e' },
            { continent: 'Americas', color: '#2ca02c' },
            { continent: 'Oceania', color: '#9467bd' }
        ];

        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right + 100}, ${margin.top})`);

        legend.selectAll('rect')
            .data(legendData)
            .enter()
            .append('rect')
            .attr('x', 0)
            .attr('y', (d, i) => i * 20)
            .attr('width', 18)
            .attr('height', 18)
            .attr('fill', d => d.color);

        legend.selectAll('text')
            .data(legendData)
            .enter()
            .append('text')
            .attr('x', 24)
            .attr('y', (d, i) => i * 20 + 9)
            .attr('dy', '0.35em')
            .text(d => d.continent)
            .attr('font-size', '12px')
            .attr('fill', 'black');
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}