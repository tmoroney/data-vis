import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

export default function GDPLifeExp() {
    const svgRef = useRef();

    const margin = { top: 50, right: 0, bottom: 50, left: 150 };
    const width = window.innerWidth - margin.left - margin.right;
    const height = window.innerHeight - margin.top - margin.bottom;

    const colours = [
        { continent: 'Asia', color: '#d62728' },
        { continent: 'Europe', color: '#1f77b4' },
        { continent: 'Africa', color: '#ff7f0e' },
        { continent: 'Americas', color: '#2ca02c' },
        { continent: 'Oceania', color: '#9467bd' }
    ];

    // Updated popRanges to include pattern IDs instead of colors
    const popRanges = [
        { max: 1000000, pattern: 'pattern1' },
        { max: 5000000, pattern: 'pattern2' },
        { max: 25000000, pattern: 'pattern3' },
        { max: 100000000, pattern: 'pattern4' },
        { max: 1000000000, pattern: 'pattern5' },
        { max: 2000000000, pattern: 'pattern6' },
    ];

    const drawChart = () => {
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');

        // Read in the data where the year is 2002
        const data = inputData.filter(d => d.year === 2002);

        // Define scales
        const x = d3.scaleLinear()
            .domain(d3.extent(data, d => d.gdpPercap))
            .range([margin.left, width - margin.right]);

        const y = d3.scaleLinear()
            .domain(d3.extent(data, d => d.lifeExp))
            .range([height - margin.bottom, margin.top]);

        // Define patterns
        function definePatterns(svg) {
            const defs = svg.append('defs');

            // Pattern 1: Diagonal lines
            defs.append('pattern')
                .attr('id', 'pattern1')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 6)
                .attr('height', 6)
                .append('path')
                .attr('d', 'M0,6 l6,-6')
                .attr('stroke', 'black')
                .attr('stroke-width', 1);

            // Pattern 2: Vertical lines
            defs.append('pattern')
                .attr('id', 'pattern2')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 4)
                .attr('height', 4)
                .append('path')
                .attr('d', 'M2,0 l0,4')
                .attr('stroke', 'black')
                .attr('stroke-width', 1);

            // Pattern 3: Horizontal lines
            defs.append('pattern')
                .attr('id', 'pattern3')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 4)
                .attr('height', 4)
                .append('path')
                .attr('d', 'M0,2 l4,0')
                .attr('stroke', 'black')
                .attr('stroke-width', 1);

            // Pattern 4: Crosshatch
            defs.append('pattern')
                .attr('id', 'pattern4')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 6)
                .attr('height', 6)
                .append('path')
                .attr('d', 'M0,6 l6,-6 M6,6 l-6,-6')
                .attr('stroke', 'black')
                .attr('stroke-width', 1);

            // Pattern 5: Dots
            defs.append('pattern')
                .attr('id', 'pattern5')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 6)
                .attr('height', 6)
                .append('circle')
                .attr('cx', 3)
                .attr('cy', 3)
                .attr('r', 1)
                .attr('fill', 'black');

            // Pattern 6: Squares
            defs.append('pattern')
                .attr('id', 'pattern6')
                .attr('patternUnits', 'userSpaceOnUse')
                .attr('width', 6)
                .attr('height', 6)
                .append('rect')
                .attr('width', 3)
                .attr('height', 3)
                .attr('fill', 'black');
        }

        // Call the function to define patterns
        definePatterns(svg);

        // Draw circles with patterns representing population ranges
        svg.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => x(d.gdpPercap))
            .attr('cy', d => y(d.lifeExp))
            .attr('r', 10) // Set to a standard small size
            .attr('fill', d => {
                const range = popRanges.find(range => d.pop <= range.max);
                return range ? `url(#${range.pattern})` : '#000000'; // Default to black if no range is found
            })
            .attr('fill-opacity', 0.7)
            .attr('stroke', 'black');

        // Add labels
        svg.selectAll('.country-label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'country-label')
            .attr('x', d => x(d.gdpPercap))
            .attr('y', d => y(d.lifeExp - 1.4))
            .text(d => d.country)
            .attr('font-size', '11px')
            .attr('font-size', d => d.country === 'Ireland' ?  '20px':'11px')
            .attr('text-anchor', 'middle')
            .attr('alignment-baseline', 'middle')
            .attr('fill', 'black')
            .attr('opacity', d => d.country === 'Ireland' ? 1 : 0.4)
            .attr('font-weight', d => d.country === 'Ireland' ? 'bold' : 'normal');

        // Add axes
        const xAxis = d3.axisBottom(x).ticks(10).tickFormat(d3.format(".2s")); // Add ticks to x-axis with labels
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(xAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px') // Make lines thin
            .attr('stroke', 'black'); // Make stroke black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        const yAxis = d3.axisLeft(y).ticks(10).tickFormat(d3.format(".2s")); // Add ticks to y-axis with labels
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(yAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px') // Make lines thin
            .attr('stroke', 'black'); // Make stroke black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('GDP per Capita')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Life Expectancy')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Adjusted the legend to display patterns
        // Add background to the legend
        svg.append('rect')
            .attr('x', width - margin.right - 220)
            .attr('y', height - margin.bottom - 220)
            .attr('width', 240)
            .attr('height', popRanges.length * 30)
            .attr('fill', 'white')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Legend for population ranges
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right - 200}, ${height - margin.bottom - 180})`);

        legend.selectAll('rect')
            .data(popRanges)
            .enter()
            .append('rect')
            .attr('x', 0)
            .attr('y', (d, i) => i * 20)
            .attr('width', 18)
            .attr('height', 18)
            .attr('fill', d => `url(#${d.pattern})`)
            .attr('stroke', 'black'); // Add stroke to make the rectangle visible

        legend.selectAll('text')
            .data(popRanges)
            .enter()
            .append('text')
            .attr('x', 24)
            .attr('y', (d, i) => i * 20 + 9)
            .attr('dy', '0.35em')
            .text(d => `< ${d.max.toLocaleString()}`)
            .attr('font-size', '12px')
            .attr('fill', 'black');

        // Add title to the legend
        legend.append('text')
            .attr('x', 0)
            .attr('y', -10)
            .text('Population Ranges')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}