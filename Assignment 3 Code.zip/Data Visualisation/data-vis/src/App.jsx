import MinardMap from "./components/MinardMap";
import LifeExpByYearBubbleChart from "./components/LifeExpByYearBubbleChart";
//import GDPLifeExp from "./components/GDPLifeExp";

function App() {

  return (
    <LifeExpByYearBubbleChart />
  );
}

export default App;
