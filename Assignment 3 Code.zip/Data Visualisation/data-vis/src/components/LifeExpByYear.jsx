import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

export default function LifeExpByYear() {
    const svgRef = useRef();

    const margin = { top: 50, right: 0, bottom: 50, left: 150 };

    const continents = [
        { continent: 'Asia', shape: d3.symbolCircle },
        { continent: 'Europe', shape: d3.symbolSquare },
        { continent: 'Africa', shape: d3.symbolTriangle },
        { continent: 'Americas', shape: d3.symbolDiamond },
        { continent: 'Oceania', shape: d3.symbolStar }
    ];

    // Prepare the data
    const data = inputData.filter(d => d.year >= 1957 && d.year <= 2007);

    const drawChart = () => {
        const width = window.innerWidth - margin.left - margin.right;
        const height = window.innerHeight - margin.top - margin.bottom;
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');

        // Define scales
        const years = [...new Set(data.map(d => d.year))]; // Extract unique years
        const x = d3.scaleBand()
            .domain(years) // Set years as discrete values
            .range([margin.left, width - margin.right])
            .padding(0.1); // Optional: add padding between the bands

        const y = d3.scaleLinear()
            .domain([20, 85]) // Adjust the y-axis for life expectancy
            .range([height - margin.bottom, margin.top]);

        // Add grid lines for x-axis (aligned halfway between ticks)
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .selectAll('line') // Add grid lines halfway between ticks
            .data(years)
            .enter()
            .append('line')
            .attr('x1', d => x(d) + x.bandwidth())
            .attr('x2', d => x(d) + x.bandwidth())
            .attr('y1', 0)
            .attr('y2', -height + margin.top + margin.bottom)
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Add grid lines for y-axis
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y)
                .ticks(10)
                .tickSize(-width + margin.left + margin.right)
                .tickFormat(''))
            .selectAll('line')
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Define symbol generator
        const symbol = d3.symbol();

        // Draw symbols (different shapes)
        svg.selectAll('path.symbol')
            .data(data)
            .enter()
            .append('path')
            .attr('class', 'symbol')
            .attr('d', d => {
                const continentInfo = continents.find(c => d.continent === c.continent);
                return symbol.type(continentInfo ? continentInfo.shape : d3.symbolCircle)();
            })
            .attr('transform', d => {
                const jitter = (Math.random() - 0.55) * 80;
                d.jitter = jitter; // Store jitter value in data for later use
                return `translate(${x(d.year) + x.bandwidth() / 2 + jitter}, ${y(d.lifeExp)})`;
            })
            .attr('fill', 'black')
            .attr('stroke', 'black')
            .attr('fill-opacity', 0.5)
            .attr('stroke-width', 1.5);

        // Add labels for Ireland
        svg.selectAll('text')
            .data(data)
            .enter()
            .append('text')
            .filter(d => d.country === 'Ireland') // Only add labels for Ireland
            .attr('x', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y', d => y(d.lifeExp) - 50) // Position the label further above the circle
            .attr('text-anchor', 'middle')
            .attr('font-size', '12px')
            .attr('fill', 'blue')
            .text(d => d.country);

        // Add arrows pointing to the data points for Ireland
        svg.selectAll('line.arrow')
            .data(data)
            .enter()
            .append('line')
            .filter(d => d.country === 'Ireland') // Only add arrows for Ireland
            .attr('x1', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y1', d => y(d.lifeExp) - 45) // Start the arrow just below the label
            .attr('x2', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y2', d => y(d.lifeExp) - 6) // End the arrow just above the circle
            .attr('stroke', 'blue')
            .attr('stroke-width', 3)
            .attr('marker-end', 'url(#arrowhead)');

        // Define the arrowhead marker
        svg.append('defs')
            .append('marker')
            .attr('id', 'arrowhead')
            .attr('viewBox', '0 0 10 10')
            .attr('refX', 5)
            .attr('refY', 5)
            .attr('markerWidth', 4)
            .attr('markerHeight', 6)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M 0 0 L 10 5 L 0 10 Z')
            .attr('fill', 'blue');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('Year')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Life Expectancy')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Add labels for the x-axis (year)
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(d3.axisBottom(x).tickFormat(d3.format('d')))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        // Add labels for the y-axis (life expectancy)
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#000000');

        // Add background to the legend
        svg.append('rect')
            .attr('x', width - margin.right - 160)
            .attr('y', height - margin.bottom - 155)
            .attr('width', 150)
            .attr('height', continents.length * 28) // Adjust height to accommodate the title
            .attr('fill', 'white')
            .attr('stroke', 'black')
            .attr('stroke-width', 1)
            .attr('opacity', 0.6);

        // Legend for continents with shapes
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right - 150}, ${height - margin.top - 120})`);

        legend.selectAll('path')
            .data(continents)
            .enter()
            .append('path')
            .attr('d', d => symbol.type(d.shape)())
            .attr('transform', (d, i) => `translate(10, ${i * 20 + 10})`)
            .attr('fill', 'black')
            .attr('stroke', 'black')
            .attr('fill-opacity', 0.5)
            .attr('stroke-width', 1.5);

        legend.selectAll('text')
            .data(continents)
            .enter()
            .append('text')
            .attr('x', 24)
            .attr('y', (d, i) => i * 20 + 9)
            .attr('dy', '0.35em')
            .text(d => `${d.continent}`)
            .attr('font-size', '12px')
            .attr('fill', 'black');

        // Add title to the legend
        legend.append('text')
            .attr('x', 0)
            .attr('y', -10)
            .text('Continents')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}