
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

export default function GDPAvgLifeExp() {
    const svgRef = useRef();

    const margin = { top: 50, right: 0, bottom: 50, left: 150 };
    const width = window.innerWidth - margin.left - margin.right;
    const height = window.innerHeight - margin.top - margin.bottom;

    const colours = [
        { continent: 'Asia', color: '#d62728' },
        { continent: 'Europe', color: '#1f77b4' },
        { continent: 'Africa', color: '#ff7f0e' },
        { continent: 'Americas', color: '#2ca02c' },
        { continent: 'Oceania', color: '#9467bd' }
    ];

    const popRanges = [
        { max: 1000000, color: 'yellow' }, // Yellow
        { max: 5000000, color: '#4b0082' }, // Indigo
        { max: 25000000, color: '#0000ff' }, // Blue
        { max: 100000000, color: '#40e0d0' }, // Turquoise
        { max: 1000000000, color: '#ff7f00' }, // Orange
        { max: 2000000000, color: '#ff0000' }, // Red
    ];

    // Read in the data and calculate the average life expectancy and GDP per capita for the years 1957-2007
    const data = [];
    let count = 0;
    let total = 0;
    for (let i = 0; i < inputData.length; i++) {
        const currentData = inputData[i];
        if (currentData.year >= 1957 && currentData.year <= 2007) {
            count++;
            total += currentData.lifeExp;
        }
        if (currentData.year === 2007) {
            data.push({
                country: currentData.country,
                continent: currentData.continent,
                lifeExp: total / count,
                gdpPercap: currentData.gdpPercap,
            });
            count = 0;
            total = 0;
        }
    }

    const drawChart = () => {
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');


        // Define scales
        const x = d3.scaleLinear()
            .domain(d3.extent(data, d => d.gdpPercap))
            .range([margin.left, width - margin.right]);

        const y = d3.scaleLinear()
            .domain(d3.extent(data, d => d.lifeExp))
            .range([height - margin.bottom, margin.top]);

        const r = d3.scaleLinear()
            .domain(d3.extent(data, d => d.pop))
            .range([5, 40]);

        // Add grid lines for x-axis
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(d3.axisBottom(x)
                .ticks(10)
                .tickSize(-height + margin.top + margin.bottom)
                .tickFormat(''))
            .selectAll('line')
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.5);

        // Add grid lines for y-axis
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y)
                .ticks(10)
                .tickSize(-width + margin.left + margin.right)
                .tickFormat(''))
            .selectAll('line')
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.5);

        // Draw circles with brightness representing population
        svg.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => x(d.gdpPercap))
            .attr('cy', d => y(d.lifeExp))
            .attr('r', 10) // Set to a standard small size
            .attr('fill', d => {
                const colour = colours.find(colour => d.continent === colour.continent);
                return colour ? colour.color : '#000000'; // Default to black if no range is found
            })
            .attr('fill-opacity', 0.7);

        // Add labels
        svg.selectAll('.country-label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'country-label')
            .attr('x', d => x(d.gdpPercap))
            .attr('y', d => y(d.lifeExp - 1.4))
            .text(d => d.country)
            .attr('font-size', '11px')
            .attr('font-size', d => d.country === 'Ireland' ?  '20px':'11px')
            .attr('text-anchor', 'middle')
            .attr('alignment-baseline', 'middle')
            .attr('fill', 'black')
            .attr('opacity', d => d.country === 'Ireland' ? 1 : 0.4)
            .attr('font-weight', d => d.country === 'Ireland' ? 'bold' : 'normal');

        // Add axes
        const xAxis = d3.axisBottom(x).ticks(10).tickFormat(d3.format(".2s")); // Add ticks to x-axis with labels
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(xAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px') // Make lines thin
            .attr('stroke', 'black'); // Make stroke black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        const yAxis = d3.axisLeft(y).ticks(10).tickFormat(d3.format(".2s")); // Add ticks to y-axis with labels
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(yAxis)
            .selectAll('.domain, .tick line')
            .attr('stroke-width', '1px') // Make lines thin
            .attr('stroke', 'black'); // Make stroke black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#8b4513');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('GDP per Capita')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Average Life Expectancy (1957-2007)')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Add background to the legend
        svg.append('rect')
            .attr('x', width - margin.right - 220)
            .attr('y', height - margin.bottom - 175)
            .attr('width', 240)
            .attr('height', colours.length * 30) // Adjust height to accommodate the title
            .attr('fill', 'white')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Legend for population ranges
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right - 200}, ${height - margin.bottom - 140})`);

        legend.selectAll('rect')
            .data(colours)
            .enter()
            .append('rect')
            .attr('x', 0)
            .attr('y', (d, i) => i * 20)
            .attr('width', 18)
            .attr('height', 18)
            .attr('fill', d => d.color);

        legend.selectAll('text')
            .data(colours)
            .enter()
            .append('text')
            .attr('x', 24)
            .attr('y', (d, i) => i * 20 + 9)
            .attr('dy', '0.35em')
            .text(d => `${d.continent}`)
            .attr('font-size', '12px')
            .attr('fill', 'black');

        // Add title to the legend
        legend.append('text')
            .attr('x', 0)
            .attr('y', -10)
            .text('Continents')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}