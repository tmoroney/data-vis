import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

export default function LifeExpByYear() {
    const svgRef = useRef();

    const margin = { top: 50, right: 0, bottom: 50, left: 150 };

    const colours = [
        { continent: 'Asia', color: '#d62728' },
        { continent: 'Europe', color: '#1f77b4' },
        { continent: 'Africa', color: '#ff7f0e' },
        { continent: 'Americas', color: '#2ca02c' },
        { continent: 'Oceania', color: '#9467bd' }
    ];

    // Updated popRanges to include pattern IDs instead of colors
    const textures = [
        { continent: 'Asia', pattern: 'pattern1' },
        { continent: 'Europe', pattern: 'pattern2' },
        { continent: 'Africa', pattern: 'pattern6' },
        { continent: 'Americas', pattern: 'pattern4' },
        { continent: 'Oceania', pattern: 'pattern5' },
    ];

    // Define patterns
    function definePatterns(svg) {
        const defs = svg.append('defs');

        // Pattern 1: Diagonal lines
        defs.append('pattern')
            .attr('id', 'pattern1')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 6)
            .attr('height', 6)
            .append('path')
            .attr('d', 'M0,6 l6,-6')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Pattern 2: Vertical lines
        defs.append('pattern')
            .attr('id', 'pattern2')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 4)
            .attr('height', 4)
            .append('path')
            .attr('d', 'M2,0 l0,4')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Pattern 3: Horizontal lines
        defs.append('pattern')
            .attr('id', 'pattern3')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 4)
            .attr('height', 4)
            .append('path')
            .attr('d', 'M0,2 l4,0')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Pattern 4: Crosshatch
        defs.append('pattern')
            .attr('id', 'pattern4')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 6)
            .attr('height', 6)
            .append('path')
            .attr('d', 'M0,6 l6,-6 M6,6 l-6,-6')
            .attr('stroke', 'black')
            .attr('stroke-width', 1);

        // Pattern 5: Dots
        defs.append('pattern')
            .attr('id', 'pattern5')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 6)
            .attr('height', 6)
            .append('circle')
            .attr('cx', 3)
            .attr('cy', 3)
            .attr('r', 1)
            .attr('fill', 'black');

        // Pattern 6: Squares
        defs.append('pattern')
            .attr('id', 'pattern6')
            .attr('patternUnits', 'userSpaceOnUse')
            .attr('width', 6)
            .attr('height', 6)
            .append('rect')
            .attr('width', 3)
            .attr('height', 3)
            .attr('fill', 'black');
    }

    // Prepare the data
    const data = inputData.filter(d => d.year >= 1957 && d.year <= 2007);

    const drawChart = () => {
        const width = window.innerWidth - margin.left - margin.right;
        const height = window.innerHeight - margin.top - margin.bottom;
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Call the function to define patterns
        definePatterns(svg);

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');

        // Define scales
        const years = [...new Set(data.map(d => d.year))]; // Extract unique years
        const x = d3.scaleBand()
            .domain(years) // Set years as discrete values
            .range([margin.left, width - margin.right])
            .padding(0.1); // Optional: add padding between the bands

        const y = d3.scaleLinear()
            .domain([20, 85]) // Adjust the y-axis for life expectancy
            .range([height - margin.bottom, margin.top]);

        // Add grid lines for x-axis (aligned halfway between ticks)
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .selectAll('line') // Add grid lines halfway between ticks
            .data(years)
            .enter()
            .append('line')
            .attr('x1', d => x(d) + x.bandwidth())
            .attr('x2', d => x(d) + x.bandwidth())
            .attr('y1', 0)
            .attr('y2', -height + margin.top + margin.bottom)
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Add grid lines for y-axis
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y)
                .ticks(10)
                .tickSize(-width + margin.left + margin.right)
                .tickFormat(''))
            .selectAll('line')
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Draw circles
        svg.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => {
                const jitter = (Math.random() - 0.55) * 80;
                d.jitter = jitter; // Store jitter value in data for later use
                return x(d.year) + x.bandwidth() / 2 + jitter;
            }) // Center the circles in the middle of the band
            .attr('cy', d => y(d.lifeExp))
            .attr('r', 6) // Set a standard size for the circles
            .attr('fill', d => {
                const texture = textures.find(c => d.continent === c.continent);
                return texture ? `url(#${texture.pattern})` : '#000000'; // Default to black if no color is found
            })
            .attr('fill-opacity', 0.5)
            .attr('stroke', 'black');

        // Add labels for Ireland
        svg.selectAll('text')
            .data(data)
            .enter()
            .append('text')
            .filter(d => d.country === 'Ireland') // Only add labels for Ireland
            .attr('x', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y', d => y(d.lifeExp) - 50) // Position the label further above the circle
            .attr('text-anchor', 'middle')
            .attr('font-size', '12px')
            .attr('fill', 'blue')
            .text(d => d.country);

        // Add arrows pointing to the data points for Ireland
        svg.selectAll('line.arrow')
            .data(data)
            .enter()
            .append('line')
            .filter(d => d.country === 'Ireland') // Only add arrows for Ireland
            .attr('x1', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y1', d => y(d.lifeExp) - 45) // Start the arrow just below the label
            .attr('x2', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y2', d => y(d.lifeExp) - 6) // End the arrow just above the circle
            .attr('stroke', 'blue')
            .attr('stroke-width', 3)
            .attr('marker-end', 'url(#arrowhead)');

        // Define the arrowhead marker
        svg.append('defs')
            .append('marker')
            .attr('id', 'arrowhead')
            .attr('viewBox', '0 0 10 10')
            .attr('refX', 5)
            .attr('refY', 5)
            .attr('markerWidth', 4)
            .attr('markerHeight', 6)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M 0 0 L 10 5 L 0 10 Z')
            .attr('fill', 'blue');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('Year')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Life Expectancy')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Add labels for the x-axis (year)
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(d3.axisBottom(x).tickFormat(d3.format('d')))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        // Add labels for the y-axis (life expectancy)
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#000000');

        // Add background to the legend
        svg.append('rect')
            .attr('x', width - margin.right - 160)
            .attr('y', height - margin.bottom - 155)
            .attr('width', 150)
            .attr('height', colours.length * 28) // Adjust height to accommodate the title
            .attr('fill', 'white')
            .attr('stroke', 'black')
            .attr('stroke-width', 1)
            .attr('opacity', 0.6);

        // Legend for continents with patterns
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right - 150}, ${height - margin.top - 120})`);

        legend.selectAll('rect')
            .data(textures)
            .enter()
            .append('rect')
            .attr('x', 0)
            .attr('y', (d, i) => i * 20)
            .attr('width', 18)
            .attr('height', 18)
            .attr('fill', d => `url(#${d.pattern})`);

        legend.selectAll('text')
            .data(textures)
            .enter()
            .append('text')
            .attr('x', 24)
            .attr('y', (d, i) => i * 20 + 9)
            .attr('dy', '0.35em')
            .text(d => `${d.continent}`)
            .attr('font-size', '12px')
            .attr('fill', 'black');

        // Add title to the legend
        legend.append('text')
            .attr('x', 0)
            .attr('y', -10)
            .text('Continents')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}