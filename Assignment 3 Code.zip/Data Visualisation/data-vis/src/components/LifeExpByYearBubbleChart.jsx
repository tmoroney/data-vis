import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import inputData from '../data/gdp-life-exp.json';

export default function LifeExpByYearBubbleChart() {
    const svgRef = useRef();

    const margin = { top: 50, right: 80, bottom: 50, left: 100 };

    const colours = [
        { continent: 'Asia', color: '#d62728' },
        { continent: 'Europe', color: '#1f77b4' },
        { continent: 'Africa', color: '#ff7f0e' },
        { continent: 'Americas', color: '#2ca02c' },
        { continent: 'Oceania', color: '#9467bd' }
    ];

    const gdpRanges = [
        { max: 1000, opacity: 0.1 },
        { max: 10000, opacity: 0.4 },
        { max: 35000, opacity: 0.6 },
        { max: 50000, opacity: 0.95 }
    ];


    // Prepare the data
    const data = inputData.filter(d => d.year >= 1957 && d.year <= 2007);

    const drawChart = () => {
        const width = window.innerWidth - margin.left - margin.right;
        const height = window.innerHeight - margin.top - margin.bottom;
        const svg = d3.select(svgRef.current)
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight);

        // Clear previous drawings
        svg.selectAll('*').remove();

        // Add a white rectangle to represent the background
        svg.append('rect')
            .attr('width', window.innerWidth)
            .attr('height', window.innerHeight)
            .attr('fill', 'white');

        // Define scales
        const years = [...new Set(data.map(d => d.year))]; // Extract unique years
        const x = d3.scaleBand()
            .domain(years) // Set years as discrete values
            .range([margin.left, width - margin.right])
            .padding(0.1); // Optional: add padding between the bands

        const y = d3.scaleLinear()
            .domain([20, 85]) // Adjust the y-axis for life expectancy
            .range([height - margin.bottom, margin.top]);

        // Add grid lines for x-axis (aligned halfway between ticks)
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .selectAll('line') // Add grid lines halfway between ticks
            .data(years)
            .enter()
            .append('line')
            .attr('x1', d => x(d) + x.bandwidth())
            .attr('x2', d => x(d) + x.bandwidth())
            .attr('y1', 0)
            .attr('y2', -height + margin.top + margin.bottom)
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Add grid lines for y-axis
        svg.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y)
                .ticks(10)
                .tickSize(-width + margin.left + margin.right)
                .tickFormat(''))
            .selectAll('line')
            .attr('stroke', '#e0e0e0')
            .attr('stroke-opacity', 0.7);

        // Draw circles
        svg.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => {
                const jitter = (Math.random() - 0.57) * 65;
                d.jitter = jitter; // Store jitter value in data for later use
                return x(d.year) + x.bandwidth() / 2 + jitter;
            }) // Center the circles in the middle of the band
            .attr('cy', d => y(d.lifeExp))
            .attr('r', d => d3.scaleSqrt()
                .domain([d3.min(data, d => d.pop), d3.max(data, d => d.pop)])
                .range([5, 24])(d.pop)) // Encode population using size
            .attr('fill', d => {
                const color = colours.find(c => d.continent === c.continent);
                return color ? color.color : '#000000'; // Default to black if no color is found
            })
            .attr('fill-opacity', d =>{
                const opacity = gdpRanges.find(range => d.gdpPercap <= range.max);
                return opacity ? opacity.opacity : 0.2; // Default to 0.2 if no range is found
            })
            .attr('stroke-width', 2)
            .attr('stroke', d => {
                if (d.country === 'Ireland') {
                    return 'black'; // Show stroke if country is Ireland
                }
                const color = colours.find(c => d.continent === c.continent);
                return color ? color.color : '#000000'; // Default to black if no color is found
            })
            .attr('stroke-opacity', d => d.country === 'Ireland' ? 1 : 0.2); // Show stroke if country is Ireland

        // Add labels for Ireland
        svg.selectAll('text')
            .data(data)
            .enter()
            .append('text')
            .filter(d => d.country === 'Ireland') // Only add labels for Ireland
            .attr('x', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y', d => y(d.lifeExp) - 50) // Position the label further above the circle
            .attr('text-anchor', 'middle')
            .attr('font-size', '12px')
            .attr('fill', 'black')
            .text(d => d.country);

        // Add arrows pointing to the data points for Ireland
        svg.selectAll('line.arrow')
            .data(data)
            .enter()
            .append('line')
            .filter(d => d.country === 'Ireland') // Only add arrows for Ireland
            .attr('x1', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y1', d => y(d.lifeExp) - 45) // Start the arrow just below the label
            .attr('x2', d => x(d.year) + x.bandwidth() / 2 + d.jitter)
            .attr('y2', d => y(d.lifeExp) - 6) // End the arrow just above the circle
            .attr('stroke', 'black')
            .attr('stroke-width', 3)
            .attr('marker-end', 'url(#arrowhead)');

        // Define the arrowhead marker
        svg.append('defs')
            .append('marker')
            .attr('id', 'arrowhead')
            .attr('viewBox', '0 0 10 10')
            .attr('refX', 5)
            .attr('refY', 5)
            .attr('markerWidth', 4)
            .attr('markerHeight', 6)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M 0 0 L 10 5 L 0 10 Z')
            .attr('fill', 'black');

        // Add axis labels
        svg.append('text')
            .attr('x', (width - margin.left - margin.right) / 2 + margin.left)
            .attr('y', height - margin.bottom + 50)
            .text('Year')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        svg.append('text')
            .attr('transform', 'rotate(-90)')
            .attr('x', -((height - margin.top - margin.bottom) / 2) - margin.top)
            .attr('y', margin.left - 50)
            .text('Life Expectancy')
            .attr('font-size', '20px')
            .attr('text-anchor', 'middle')
            .attr('fill', 'black');

        // Add labels for the x-axis (year)
        svg.append('g')
            .attr('transform', `translate(0, ${height - margin.bottom})`)
            .call(d3.axisBottom(x).tickFormat(d3.format('d')))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        // Add labels for the y-axis (life expectancy)
        svg.append('g')
            .attr('transform', `translate(${margin.left}, 0)`)
            .call(d3.axisLeft(y))
            .selectAll('path, line')
            .attr('stroke', 'black'); // Set the stroke color to black

        svg.selectAll('.tick text')
            .attr('font-size', '12px')
            .attr('fill', '#000000');

        // Add a more detailed legend to explain all attributes
        const legend = svg.append('g')
            .attr('transform', `translate(${width - margin.right + 40}, ${margin.top})`);

        // Legend for continent colors
        legend.append('text')
            .attr('x', 0)
            .attr('y', 0)
            .text('Continent (Color)')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');

        colours.forEach((item, i) => {
            legend.append('rect')
                .attr('x', 0)
                .attr('y', 20 + i * 20)
                .attr('width', 18)
                .attr('height', 18)
                .attr('fill', item.color);

            legend.append('text')
                .attr('x', 24)
                .attr('y', 20 + i * 20 + 13)
                .text(item.continent)
                .attr('font-size', '12px')
                .attr('fill', 'black');
        });

        // Legend for population size (bubble size)
        legend.append('text')
            .attr('x', 0)
            .attr('y', colours.length * 20 + 40)
            .text('Population (Size)')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');

        const sizeScale = d3.scaleSqrt()
            .domain([d3.min(inputData, d => d.pop), d3.max(inputData, d => d.pop)])
            .range([5, 22]);

        [1e6, 1e8, 1e9].forEach((pop, i) => {
            legend.append('circle')
                .attr('cx', 10)
                .attr('cy', colours.length * 20 + 60 + i * 30)
                .attr('r', sizeScale(pop))
                .attr('fill', 'none')
                .attr('stroke', 'black');

            legend.append('text')
                .attr('x', 30)
                .attr('y', colours.length * 20 + 60 + i * 30 + 5)
                .text(`${pop / 1e6}M`)
                .attr('font-size', '12px')
                .attr('fill', 'black');
        });

        // Legend for GDP per capita (opacity)
        legend.append('text')
            .attr('x', 0)
            .attr('y', colours.length * 20 + 160)
            .text('GDP per Capita (Opacity)')
            .attr('font-size', '14px')
            .attr('font-weight', 'bold')
            .attr('fill', 'black');

        gdpRanges.forEach((gdp, i) => {
            legend.append('circle')
                .attr('cx', 10)
                .attr('cy', colours.length * 20 + 180 + i * 30)
                .attr('r', 12)
                .attr('fill', 'black')
                .attr('fill-opacity', gdp.opacity);

            legend.append('text')
                .attr('x', 30)
                .attr('y', colours.length * 20 + 180 + i * 30 + 5)
                .text(`$${gdp.max / 1e3}k`)
                .attr('font-size', '12px')
                .attr('fill', 'black');
        });
    };

    useEffect(() => {
        drawChart();
    }, []);

    return <svg ref={svgRef} />;
}
